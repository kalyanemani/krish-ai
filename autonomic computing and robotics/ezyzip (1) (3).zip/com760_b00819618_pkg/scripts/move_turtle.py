#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from math import pow,atan2,sqrt
import time


PI = 3.1415926535897

global hit_wall_flag
global go_home
hit_wall_flag = False
go_home = False


class TurtleBote:
    

    def __init__(self):


        rospy.init_node('Leader', anonymous=True)

        
        self.velocity_publishe = rospy.Publisher('/turtle1/cmd_vel',Twist, queue_size=10)


        self.pose_subscribe = rospy.Subscriber('/turtle1/pose', Pose, self.update_pos)
    
        self.pos = Pose()
    
        self.rate = rospy.Rate(10)
   

    def update_pos(self, data):
        self.pos = data
        self.pos.x = round(self.pos.x, 4)
        self.pos.y = round(self.pos.y, 4)
        self.pos.theta = round(self.pos.theta,4)


    def euclidean_distance(self, goal_pos):
        return sqrt(pow((goal_pos.x - self.pos.x), 2) +
                    pow((goal_pos.y - self.pos.y), 2))
    
    def linear_vel(self, goal_pos, constant=1.5):
        return constant * self.euclidean_distance(goal_pos)

    def steering_angle(self, goal_pos):
        return atan2(goal_pos.y - self.pos.y, goal_pos.x - self.pos.x)

    def angular_vel(self, goal_pos, constant=6):
        return constant * (self.steering_angle(goal_pos) - self.pos.theta)
    
    def angular_vel_rotate(self, goal_pos, constant=6):
        return constant * (goal_pos.theta - self.pos.theta)

    def gostarttheta(self):

        goal_pos = Pose()
   
        goal_pos.x = float(5.5)
        goal_pos.y = float(7.0)
        goal_pos.theta = self.steering_angle(goal_pos)
        
        return goal_pos.theta, goal_pos.x, goal_pos.y



    def movetogoal(self, move_x, move_y):

        move_x = move_x
        move_y = move_y

        goal_pos = Pose()
        if (move_x and move_y) == 0:
            goal_pos.x = goal_pos.x
            goal_pos.y = goal_pos.y
            goal_pos.theta = goal_pos.theta
   
        elif (move_x == 2.0 and move_y != 2.0):
            goal_pos.x = goal_pos.x
            goal_pos.y = move_y
            goal_pos.theta = self.steering_angle(goal_pos)
        
        elif (move_x != 4.0 and move_y == 8.0):
            goal_pos.x = move_x
            goal_pos.y = goal_pos.y
            goal_pos.theta = goal_pose.theta
        
        else:
            goal_pos.x = move_x
            goal_pos.y = move_y
            goal_pos.theta = self.steering_angle(goal_pos)

        print("goal pos",goal_pos.x)


        distance_tolerance = 0.5
        self.vel_msg = Twist()
        global hit_wall_flag
        global go_home
  
        hit_wall_flag = False
        go_home = False



        while self.euclidean_distance(goal_pos) >= distance_tolerance and hit_wall_flag == False :


             self.vel_msg.linear.x = 0.7
             self.vel_msg.linear.y = 0
             self.vel_msg.linear.z = 0
 
             self.vel_msg.angular.x = 0
             self.vel_msg.angular.y = 0
             self.vel_msg.angular.z = 0.1
   
             self.velocity_publishe.publish(self.vel_msg)
             print("pose of the robot theta",self.pos.theta)
             print("pos gen msg ",self.pos)
  
             if((self.pos.x > 10.0 or self.pos.y > 10.0 or self.pos.x <= 1.0 or self.pos.y <=1.0) and go_home == False):
                 print("wall")
                 hit_wall_flag = True
                 print("hit wall flag",hit_wall_flag)
                 print("go home? True go home, flase dont",go_home)
                 go_home = True
                 print("I am going home" ,go_home)
                  

             self.rate.sleep()
        self.vel_msg.linear.x = 5.5
        self.vel_msg.angular.z = 0
        self.velocity_publishe.publish(self.vel_msg)

    def movetohome(self, move_x, move_y):



        goal_pos = Pose()
        if (move_x and move_y) == 0:
            goal_pos.x = goal_pos.x
            goal_pos.y = goal_pos.y
            goal_pos.theta = goal_pos.theta
        
        elif (move_x == 5.5 and move_y != 5.5):
            goal_pos.x = goal_pos.x
            goal_pos.y = move_y
            goal_pos.theta = self.steering_angle(goal_pos)

        elif (move_x == 5.5 and move_y == 5.5):
            goal_pos.x = move_x
            goal_pos.y = goal_pos.y
            goal_pos.theta = goal_pos.theta
         
        else:
            goal_pos.x = move_x
            goal_pos.y = move_y
            goal_pos.theta = self.steering_angle(goal_pos)

        print("goal pos", goal_pos.x)



        distance_tolerance = 0.5
        self.vel_msg = Twist()

        while self.euclidean_distance(goal_pos) >= distance_tolerance:

            self.vel_msg.linear.x = 0.7
            self.vel_msg.linear.y = 0
            self.vel_msg.linear.z = 0

            self.vel_msg.angular.x = 0
            self.vel_msg.angular.y = 0 
            self.vel_msg.angular.z = self.angular_vel_rotate(goal_pos)
         
            self.velocity_publishe.publish(self.vel_msg)
            print("pose of the robot theta", self.pos.theta)
            print("pose gen msg ", self.pos)

            self.rate.sleep()
        
        self.vel_msg.linear.x = 5.5
        self.vel_msg.angular.z = 0
        self.velocity_publishe.publish(self.vel_msg)
 

    def turn(self, goal_pos):
        theta_input = goal_pos
        goal_pos = Pose()
        goal_pos.theta = theta_input

        tolerance = 0.0001


        print(self.angular_vel_rotate(goal_pos))

        self.vel_msg = Twist()

        while abs(goal_pos.theta - self.pos.theta) >= tolerance:

            self.vel_msg.linear.x = 0.7
            self.vel_msg.linear.y = 0
            self.vel_msg.linear.z = 0

            self.vel_msg.angular.x = 0
            self.vel_msg.angular.y = 0
            self.vel_msg.angular.z = self.angular_vel_rotate(goal_pos)


            self.velocity_publishe.publish(self.vel_msg)
            print("pose of the robot theta", self.pos.theta)
            self.rate.sleep()


        self.vel_msg.linear.x = 5.5
        self.vel_msg.angular.z = 0
        self.velocity_publishe.publish(self.vel_msg)



    def poseCallback(pos_message):
        global x_robot
        global y_robot,yaw_robot
        x_robot = pos_message.x
        y_robot = pos_message.y
        yaw_robot = pos_message.theta


    def rotat():
        global x_robot
        global y_robot, yaw_robot
       

        position_topic = "/turtle/pose"
        pose_subscribe = rospy.Subscriber(position_topic, Pose, poseCallback)
        Robot_pose=pose()
        print(Robot_pose.theta)
        print(pose_subscriber,yaw_robot)

        rospy.init_node('rotate_robot', anonymous=True)
        velocity_publishe = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        vel_msg = Twist()


        position_topic = "/turtle/pose"
        pose_subscribe = rospy.Subscriber(position_topic, Pose, poseCallback)
        print("Let's rotate your robot")
        speed = input("input your speed (degrees/sec):")
        angle = input("Type your distance (degrees):")
        clockwise = input("clockwise?: ")

        angular_speed = speed*2*PI/360
        relative_angle = angle*2*PI/360


        vel_msg.linear.x=0
        vel_msg.linear.y=0
        vel_msg.linear.z=0
        vel_msg.angular.x = 0
        vel_msg.angular.y = 0.5

        if clockwise:
            vel_msg.angular.z = -abs(angular_speed)
        else:
            vel_msg.angular.z = abs(angular_speed)
      
        t0 = rospy.Time.now().to_sec()
        current_angle = 0
 
        while(current_angle < relative_angle):

            velocity_publishe.publish(vel_msg)
            t1 = rospy.Time.now().to_sec()
            current_angle = angular_speed*(t1-t0)
 

        vel_msg.angular.z = 0
        velocity_publishe.publish(vel_msg)
        position_topic = "/turtle/pose"
        pose_subscribr = rospy.Subscriber(position_topic, Pose, poseCallback)
    

        print(pose_subscriber, yaw_robot)

    def move():

        rospy.init_node('robot_cleaner', anonymous=True)
        velocity_publishe = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        vel_msg = Twist()

        print("Let's move your robot")
        speed = input("Input your speed:")
        distance_x = input("Type your distance in the x direction:")
        distance_y = input("Type your diatance in the y direction:")
        isForward = True
        


        if (isForward):
            vel_msg.linear.x = -abs(distance_x)
            vel_msg.linear.y = abs(distance_y)

        else:
            vel_msg.linear.x = -abs(speed)



        vel_msg.linear.z = 0
        vel_msg.angular.x = 0 
        vel_msg.angular.y = 0
        vel_msg.angular.z = 0
   
        if(distance_x == 0):
            distance = distance_y
        else:
            distance = distance_z
   
        while True:
   
            t0 = float(rospy.Time.now().to_sec())
            current_distance = 0

            current_distance = abs(4 * math.sqrt(((x - x0) ** 2) + ((y - y0) ** 2)))
            while (abs(current_distance - distance) >0.01):
                print(current_distance,distance)
                velocity_publisher.publish(vel_msg)
                t1 = float(rospy.Time.now().to_sec())
                current_distance = speed * (t1 - t0)


        vel_msg.linear.x = 0
        vel_msg.linear.y = 0
        velocity_publishe.publish(vel_msg)
        

if __name__ == '__main__':
    try:
        x_robot = 5.544445
        y_robot = 5.544445
        yaw_robot = 0
        global a, b
        global x_starting, y_starting
  

        x_starting = 1.0
        y_starting = 1.0
        a = 12
        b = 0.5
        x_count = 0
        y_count = 0
        rotate_count = 0
        x = TurtleBote()
        starting_theta,goal_x,goal_y = x.gostarttheta()
        print(starting_theta)
        print(goal_x,goal_y)
        x.turn(float(starting_theta))
        x.movetogoal(goal_x, goal_y)
        x.turn(float(5.5))
        turn_total = 20
        turn = 0
   

        mode_1 = False
        mode_2 = True
        stop_program = True
   
        while(stop_program == True):

            while(turn<=20 and mode_2 == True ):

                if (turn % 2) == 0 or turn == 0:
                    if (x_count % 2 ==0 or x_count ==0):
                        goal_x = a + goal_x
                    else:
                        goal_x = -a + goal_x
  
                    print(goal_x,goal_y)
                    
                    goal_y = goal_y
                    x.movetogoal(goal_x, goal_y)
                    x_count = x_count + 1

                else:
                    
                    goal_x = goal_x
                    goal_y = b + goal_y

                    x.movetogoal(goal_x, goal_y)
                    y_count = y_count + 1

                print(goal_x, goal_y)

                if (hit_wall_flag == True):



                   go_home = True
                   print(go_home)
                   starting_theta, goal_x, goal_y = x.gostarttheta()
                   print(starting_theta)
                   print(goal_x, goal_y)

                   x.turn(float(starting_theta))
                   x.movetogoal(goal_x, goal_y)
                   
                   turn_total = 20
                   rotate_count = 0
                   turn = 100
                   x_count = 0
                   y_count = 0
                
                   mode_1 = False
                   mode_2 = True
                   print("mode_1",mode_1)
                   print(turn)
                   break
             
                print(turn)
         
                if (rotate_count ==0 or rotate_count ==2):
                  x.turn(float(90*2 * PI / 360))
                elif(rotate_count ==1):
                 
                 x.turn(float(-180 * 2 * PI / 360))
                elif(rotate_count ==3):
          
                 x.turn(float(-0 * 2 * PI / 360))

                rotate_count =rotate_count +1
          
                if (rotate_count >= 10):
             
                    rotate_count = 0
                print(goal_x)
     
                turn = turn + 1
                mode_2 = True
            while(mode_2 == True):
                print("you hit a wall, out of loop or you have finished your pattern")
                starting_theta, goal_x, goal_y = x.gostarttheta()
                print(goal_x, goal_y)
                x.movetogoal(5.5,5.5)
                x.turn(float(starting_theta))
                move_x = float(5.5)
                move_y = float(5.5)
                print("we are going home and should go to location x, y", goal_x , goal_y)
                x.movetohome(goal_x, goal_y)
                x.turn(float(5.5))
                turn_total = 20
                rotate_count = 0
                turn = 0
                x_count = 0
                y_count = 0
                a = float(12)
                b = float(0.5)
                mode_1 = True
                mode_2 = False
                print("mode_1 : ",mode_1)

    except rospy.ROSInterruptException:
        pass
        



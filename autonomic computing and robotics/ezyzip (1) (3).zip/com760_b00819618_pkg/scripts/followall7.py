#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import time


class Robot:

    def __init__(self):
        rospy.init_node('robot_control_node')
        self.pub_ = rospy.Publisher('/com760bot/cmd_vel', Twist, queue_size=1)
        self.laser_subscribe = rospy.Subscriber('/com760bot/laser/scan', LaserScan, self.laserCallback, callback_args=None, queue_size=1)
        self.comd = Twist()
        self.lasermsg = LaserScan()
        self.ctrl_c = False
        self.rate = rospy.Rate(0.5)
        rospy.on_shutdown(self.shutdownHook)
   
    def publishComd(self):
        while not self.ctrl_c:
            connections = self.pub_.get_num_connections()
            if connections > 0:
                self.pub_.publish(self.comd)
                break
            else:
                self.rate.sleep()

    def shutdownHook(self):
        self.ctrl_c = True
 
    def laserCallback(self, msg):
        self.lasermsg = msg

    def getLaserAt(self, pos):
        time.sleep(1)
        return self.lasermsg.ranges[pos]

    def stopRobot(self):
        self.comd.linear.x = 0.0
        self.comd.angular.z = 0.0
 
        self.publishComd()


    def moveStraight(self):
        self.comd.linear.x = 0.5
        self.comd.linear.y = 0
        self.comd.linear.z = 0
        self.comd.angular.x = 0
        self.comd.angular.y = 0
        self.comd.angular.z = 0
      
        self.publishComd()

    def turn(self, clockwise, speed, time):

        self.comd.linear.x = 0
        self.comd.linear.y = 0
        self.comd.linear.z = 0
        self.comd.angular.x = 0
        self.comd.angular.y = 0
        

        if clockwise:
            self.comd.angular.z = -speed
        else:
            self.comd.angular.z = speed
        i = 0
        
        while (i <= time):
        
            self.pub_.publish(self.comd)
            i += 1
            self.rate.sleep()

        self.stopRobot()


class mazeSolve:
    def __init__(self):
        print("I'm initializing...")
        self.RB = Robot()
        self.LaserFront = self.RB.getLaserAt(360)
        self.clockwise = True
        self.turn_speed = 0.785
        self.turn_time = 1


    def move(self):
        while self.LaserFront > 1:
            self.RB.moveStraight()
            self.LaserFront = self.RB.getLaserAt(360)
            print("moving forward, Distance: ", self.LaserFront)
        self.RB.stopRobot()

    def turn(self):
        northEast = self.RB.getLaserAt(180)
        northWest = self.RB.getLaserAt(180)
        print("northEast: ", northEast, "northWest", northWest)
        if northEast >= northWest:
            while self.LaserFront < 1:
                self.RB.turn(self.clockwise, self.turn_speed, self.turn_time)
                self.LaserFront = self.RB.getLaserAt(360)
                print("point to northEast")
        else:
            while self.LaserFront < 1:
                self.RB.turn((not self.clockwise), self.turn_speed, self.turn_time)
                self.LaserFront = self.RB.getLaserAt(360)
                print("point to northWest")
        self.RB.stopRobot()
    def solveMaz(self):
        while not self.RB.ctrl_c:
            self.move()
            self.turn()


if  __name__ == '__main__':

     robo = mazeSolve()
     robo.solveMaz()    
